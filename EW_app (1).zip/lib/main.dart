import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_jailbreak_detection/flutter_jailbreak_detection.dart';
import 'acuse.dart';

const purple = Color(0xFF5B2A86), yellow = Color(0xFFFFC107);

// Precios de referencia en USD/tonelada (CFR Cuba), estimados nov-2026. Confirmar con cotización del proveedor.
const List<Map<String, Object>> refProducts = [
  {'name': 'Urea Prilada', 'price': 450.0, 'season': 'Nov-Feb y Abr-Jun', 'demand': 'Muy alta'},
  {'name': 'NPK 16-16-16', 'price': 500.0, 'season': 'Oct-Feb (campaña de frío)', 'demand': 'Alta'},
  {'name': 'Sulfato de Amonio', 'price': 310.0, 'season': 'Mar-Jun (arroz, caña)', 'demand': 'Media'},
  {'name': 'Cloruro de Potasio', 'price': 375.0, 'season': 'Nov-Feb y May-Jul', 'demand': 'Media'},
];
final db = FirebaseFirestore.instance;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // Modo offline: los pedidos se guardan en el teléfono y se sincronizan solos.
  db.settings = const Settings(persistenceEnabled: true, cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED);
  runApp(const EWApp());
}

class EWApp extends StatelessWidget {
  const EWApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'E&W',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: purple, primary: purple, secondary: yellow),
          appBarTheme: const AppBarTheme(backgroundColor: purple, foregroundColor: yellow),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: yellow, foregroundColor: purple),
          useMaterial3: true,
        ),
        home: FutureBuilder<bool>(
          future: FlutterJailbreakDetection.jailbroken, // escudo: bloquea dispositivos con root
          builder: (c, s) {
            if (!s.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
            if (s.data!) return const Scaffold(body: Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Dispositivo no seguro (root). E&W no puede ejecutarse aquí.', textAlign: TextAlign.center))));
            return StreamBuilder<User?>(
              stream: FirebaseAuth.instance.authStateChanges(),
              builder: (c, a) => a.data == null ? const Login() : Home(uid: a.data!.uid),
            );
          },
        ),
      );
}

class Login extends StatefulWidget {
  const Login({super.key});
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final email = TextEditingController(), pass = TextEditingController();
  int fails = 0;
  DateTime? lockUntil;
  String? err;

  Future<void> enter() async {
    if (lockUntil != null && DateTime.now().isBefore(lockUntil!)) {
      setState(() => err = 'Demasiados intentos. Espera 5 minutos.');
      return;
    }
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: pass.text);
    } on FirebaseAuthException {
      fails++;
      if (fails >= 5) { lockUntil = DateTime.now().add(const Duration(minutes: 5)); fails = 0; }
      setState(() => err = 'Correo o contraseña incorrectos');
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: purple,
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
                child: Image.asset('assets/logo.jpg', height: 140),
              ),
              const SizedBox(height: 16),
              const Text('E&W', style: TextStyle(fontSize: 44, fontWeight: FontWeight.bold, color: yellow)),
              const Text('Este & Oeste', style: TextStyle(color: Colors.white, fontSize: 18)),
              const SizedBox(height: 32),
              TextField(controller: email, keyboardType: TextInputType.emailAddress, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(labelText: 'Correo', labelStyle: TextStyle(color: yellow))),
              TextField(controller: pass, obscureText: true, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(labelText: 'Contraseña', labelStyle: TextStyle(color: yellow))),
              if (err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err!, style: const TextStyle(color: yellow))),
              const SizedBox(height: 24),
              SizedBox(width: double.infinity, child: FilledButton(style: FilledButton.styleFrom(backgroundColor: yellow, foregroundColor: purple), onPressed: enter, child: const Text('Entrar'))),
            ]),
          ),
        ),
      );
}

class Home extends StatefulWidget {
  final String uid;
  const Home({super.key, required this.uid});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  bool admin = false;
  @override
  void initState() {
    super.initState();
    db.doc('users/${widget.uid}').get().then((d) { if (mounted) setState(() => admin = d.data()?['role'] == 'admin'); });
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(['Pedidos', 'Catálogo', 'Acuse'][tab]), actions: [IconButton(icon: const Icon(Icons.logout), onPressed: () => FirebaseAuth.instance.signOut())]),
        body: [Orders(uid: widget.uid, admin: admin), Catalog(admin: admin), AcuseScreen(uid: widget.uid)][tab],
        floatingActionButton: (tab == 0 || (tab == 1 && admin))
            ? FloatingActionButton(onPressed: () => tab == 0 ? newOrder(c) : newProduct(c), child: const Icon(Icons.add))
            : null,
        bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Pedidos'),
          NavigationDestination(icon: Icon(Icons.eco), label: 'Catálogo'),
          NavigationDestination(icon: Icon(Icons.description), label: 'Acuse'),
        ]),
      );

  Future<void> newProduct(BuildContext c) async {
    final n = TextEditingController(), p = TextEditingController();
    Map<String, Object>? ref;
    await showDialog(context: c, builder: (_) => AlertDialog(
      title: const Text('Nuevo nutriente'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Wrap(spacing: 6, children: [
          for (final r in refProducts)
            ActionChip(label: Text(r['name'] as String, style: const TextStyle(fontSize: 12)), onPressed: () { ref = r; n.text = r['name'] as String; p.text = '${r['price']}'; }),
        ]),
        TextField(controller: n, decoration: const InputDecoration(labelText: 'Nombre')),
        TextField(controller: p, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Precio')),
      ]),
      actions: [TextButton(onPressed: () {
        final price = double.tryParse(p.text);
        if (n.text.trim().isEmpty || price == null || price <= 0) return;
        unawaited(db.collection('products').add({'name': n.text.trim(), 'price': price, if (ref != null) 'season': ref!['season'], if (ref != null) 'demand': ref!['demand']}));
        Navigator.pop(c);
      }, child: const Text('Guardar'))],
    ));
  }

  Future<void> newOrder(BuildContext c) async {
    final prods = await db.collection('products').get();
    if (prods.docs.isEmpty || !c.mounted) return;
    final client = TextEditingController(), qty = TextEditingController(text: '1');
    var sel = prods.docs.first;
    await showDialog(context: c, builder: (_) => StatefulBuilder(builder: (c, set) => AlertDialog(
      title: const Text('Nuevo pedido'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: client, decoration: const InputDecoration(labelText: 'Cliente')),
        DropdownButton<QueryDocumentSnapshot>(isExpanded: true, value: sel, items: [for (final d in prods.docs) DropdownMenuItem(value: d, child: Text('${d['name']}  \$${d['price']}'))], onChanged: (v) => set(() => sel = v!)),
        TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cantidad')),
      ]),
      actions: [TextButton(onPressed: () {
        final q = int.tryParse(qty.text);
        if (client.text.trim().isEmpty || q == null || q < 1 || q > 10000) return;
        // Sin await: funciona offline y se envía solo al volver internet.
        unawaited(db.collection('orders').add({
          'uid': widget.uid, 'client': client.text.trim(), 'product': sel['name'], 'qty': q,
          'total': (sel['price'] as num) * q, 'status': 'Pendiente', 'createdAt': FieldValue.serverTimestamp(),
        }));
        Navigator.pop(c);
      }, child: const Text('Crear'))],
    )));
  }
}

class Orders extends StatelessWidget {
  final String uid; final bool admin;
  const Orders({super.key, required this.uid, required this.admin});
  static const states = ['Pendiente', 'Confirmado', 'En ruta', 'Entregado'];

  @override
  Widget build(BuildContext c) {
    final q = admin ? db.collection('orders') : db.collection('orders').where('uid', isEqualTo: uid);
    return StreamBuilder<QuerySnapshot>(
      stream: q.snapshots(includeMetadataChanges: true),
      builder: (c, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.docs.isEmpty) return const Center(child: Text('Sin pedidos'));
        return ListView(children: [
          for (final d in s.data!.docs)
            ListTile(
              leading: Icon(d.metadata.hasPendingWrites ? Icons.cloud_off : Icons.cloud_done, color: d.metadata.hasPendingWrites ? Colors.orange : purple),
              title: Text('${d['client']} · ${d['product']} x${d['qty']}'),
              subtitle: Text('Total \$${d['total']}  ·  ${d['status']}'),
              trailing: admin ? PopupMenuButton<String>(onSelected: (v) => d.reference.update({'status': v}), itemBuilder: (_) => [for (final x in states) PopupMenuItem(value: x, child: Text(x))]) : null,
            ),
        ]);
      },
    );
  }
}

class Catalog extends StatelessWidget {
  final bool admin;
  const Catalog({super.key, required this.admin});
  @override
  Widget build(BuildContext c) => StreamBuilder<QuerySnapshot>(
        stream: db.collection('products').snapshots(),
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final docs = s.data!.docs;
          if (docs.isEmpty) {
            return Center(
              child: admin
                  ? FilledButton.icon(
                      style: FilledButton.styleFrom(backgroundColor: yellow, foregroundColor: purple),
                      icon: const Icon(Icons.download),
                      label: const Text('Cargar catálogo de referencia'),
                      onPressed: () { for (final r in refProducts) { unawaited(db.collection('products').add(r)); } })
                  : const Text('Catálogo vacío'),
            );
          }
          return ListView(children: [
            for (final d in docs)
              Builder(builder: (_) {
                final m = d.data() as Map<String, dynamic>;
                return ListTile(
                  leading: const Icon(Icons.eco, color: purple),
                  title: Text(m['name']),
                  onTap: admin ? () => editPrice(c, d) : null,
                  subtitle: Text('Temporada: ${m['season'] ?? '-'}  ·  Demanda: ${m['demand'] ?? '-'}'),
                  trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('\$${m['price']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    const Text('USD/t ref.', style: TextStyle(fontSize: 10)),
                  ]),
                );
              }),
          ]);
        },
      );
}

Future<void> editPrice(BuildContext c, QueryDocumentSnapshot d) async {
  final p = TextEditingController(text: '${(d.data() as Map)['price']}');
  await showDialog(
    context: c,
    builder: (_) => AlertDialog(
      title: Text('Precio: ${d['name']}'),
      content: TextField(controller: p, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'USD por tonelada')),
      actions: [
        TextButton(
          onPressed: () {
            final v = double.tryParse(p.text.replaceAll(',', '.'));
            if (v == null || v <= 0) return;
            unawaited(d.reference.update({'price': v}));
            Navigator.pop(c);
          },
          child: const Text('Guardar'),
        ),
      ],
    ),
  );
}
