import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

const _p = PdfColor.fromInt(0xFF5B2A86), _y = PdfColor.fromInt(0xFFFFC107);
const acuseProducts = ['Urea Prilada', 'NPK 16-16-16', 'Sulfato de Amonio', 'Cloruro de Potasio'];
const acuseModels = ['Empresa estatal', 'Mipyme privada', 'Cooperativa (CCS/CPA/UBPC)', 'Trabajador por cuenta propia', 'Otro'];

String _t2(int x) => x.toString().padLeft(2, '0');

class AcuseScreen extends StatefulWidget {
  final String uid;
  const AcuseScreen({super.key, required this.uid});
  @override
  State<AcuseScreen> createState() => _AcuseState();
}

class _AcuseState extends State<AcuseScreen> {
  final f = GlobalKey<FormState>();
  final company = TextEditingController(), email = TextEditingController(), tons = TextEditingController(), rep = TextEditingController();
  String product = acuseProducts.first, model = acuseModels.first;

  Future<void> send() async {
    if (!f.currentState!.validate()) return;
    final n = DateTime.now();
    final folio = 'EW-${n.year}${_t2(n.month)}${_t2(n.day)}-${_t2(n.hour)}${_t2(n.minute)}';
    final t = double.parse(tons.text.replaceAll(',', '.'));
    // Se guarda también en la nube (funciona offline) para dar servicio personalizado.
    unawaited(FirebaseFirestore.instance.collection('acuses').add({
      'uid': widget.uid, 'folio': folio, 'company': company.text.trim(), 'model': model, 'email': email.text.trim(),
      'product': product, 'tons': t, 'rep': rep.text.trim(), 'createdAt': FieldValue.serverTimestamp(),
    }));
    final bytes = await _buildPdf(folio, '${_t2(n.day)}/${_t2(n.month)}/${n.year}', t);
    await Printing.sharePdf(bytes: bytes, filename: 'acuse_$folio.pdf'); // guardar / compartir / descargar
  }

  Future<Uint8List> _buildPdf(String folio, String date, double t) async {
    final logo = pw.MemoryImage((await rootBundle.load('assets/logo.jpg')).buffer.asUint8List());
    pw.Widget row(String k, String v) => pw.Container(
          padding: const pw.EdgeInsets.symmetric(vertical: 9, horizontal: 10),
          decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey300))),
          child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.SizedBox(width: 160, child: pw.Text(k, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: _p))),
            pw.Expanded(child: pw.Text(v)),
          ]),
        );
    final doc = pw.Document();
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (_) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Container(
          color: _p,
          padding: const pw.EdgeInsets.all(16),
          child: pw.Row(children: [
            pw.Container(color: PdfColors.white, padding: const pw.EdgeInsets.all(6), child: pw.Image(logo, height: 70)),
            pw.SizedBox(width: 16),
            pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('E&W', style: pw.TextStyle(fontSize: 32, fontWeight: pw.FontWeight.bold, color: _y)),
              pw.Text('Este & Oeste - Nutrientes vegetales', style: const pw.TextStyle(color: PdfColors.white)),
            ]),
          ]),
        ),
        pw.Container(height: 5, color: _y),
        pw.SizedBox(height: 22),
        pw.Text('ACUSE DE RECIBO DE INFORMACION', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold, color: _p)),
        pw.SizedBox(height: 4),
        pw.Text('Folio: $folio'),
        pw.SizedBox(height: 14),
        row('Fecha', date),
        row('Empresa cubana', company.text.trim()),
        row('Modelo de negocio', model),
        row('Correo electronico', email.text.trim()),
        row('Producto', product),
        row('Cantidad solicitada', '${t.toStringAsFixed(t == t.roundToDouble() ? 0 : 1)} toneladas (minimo 20 t)'),
        row('Representante legal', rep.text.trim()),
        pw.SizedBox(height: 18),
        pw.Text('E&W acusa recibo de la informacion anterior, que sera utilizada unicamente para ofrecer un servicio personalizado. Este acuse no constituye un contrato ni una oferta en firme.', style: const pw.TextStyle(fontSize: 10)),
        pw.SizedBox(height: 60),
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceAround, children: [
          pw.Column(children: [pw.Container(width: 180, height: 1, color: _p), pw.SizedBox(height: 4), pw.Text('Representante legal', style: const pw.TextStyle(fontSize: 10))]),
          pw.Column(children: [pw.Container(width: 180, height: 1, color: _p), pw.SizedBox(height: 4), pw.Text('Recibido por E&W', style: const pw.TextStyle(fontSize: 10))]),
        ]),
        pw.Spacer(),
        pw.Container(height: 3, color: _y),
        pw.SizedBox(height: 6),
        pw.Text('MxCu Ventures S.A. - Quintana Roo, Mexico', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
      ]),
    ));
    return doc.save();
  }

  Widget field(TextEditingController c, String label, {TextInputType? type, String? Function(String?)? v}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextFormField(controller: c, keyboardType: type, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
            validator: v ?? (x) => (x == null || x.trim().isEmpty) ? 'Obligatorio' : null),
      );

  @override
  Widget build(BuildContext c) => SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: f,
          child: Column(children: [
            field(company, 'Nombre de la empresa cubana'),
            DropdownButtonFormField<String>(value: model, decoration: const InputDecoration(labelText: 'Modelo de negocio', border: OutlineInputBorder()), items: [for (final m in acuseModels) DropdownMenuItem(value: m, child: Text(m))], onChanged: (v) => model = v!),
            const SizedBox(height: 12),
            field(email, 'Correo electrónico', type: TextInputType.emailAddress, v: (x) => (x == null || !x.contains('@') || !x.contains('.')) ? 'Correo no válido' : null),
            DropdownButtonFormField<String>(value: product, decoration: const InputDecoration(labelText: 'Producto', border: OutlineInputBorder()), items: [for (final p in acuseProducts) DropdownMenuItem(value: p, child: Text(p))], onChanged: (v) => product = v!),
            const SizedBox(height: 12),
            field(tons, 'Toneladas (mínimo 20)', type: const TextInputType.numberWithOptions(decimal: true), v: (x) {
              final t = double.tryParse((x ?? '').replaceAll(',', '.'));
              return (t == null || t < 20) ? 'El mínimo es 20 toneladas' : null;
            }),
            field(rep, 'Representante legal'),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFFC107), foregroundColor: const Color(0xFF5B2A86), padding: const EdgeInsets.all(14)),
              onPressed: send, icon: const Icon(Icons.download), label: const Text('Generar y descargar acuse'))),
          ]),
        ),
      );
}
