# E&W (Este & Oeste) – Gestión de pedidos de nutrientes vegetales

## Puesta en marcha
0. Incluye assets/logo.jpg (copia la carpeta assets (logo e ícono) al proyecto).
1. Instala Flutter y Android Studio. En una carpeta vacía: `flutter create ew_app`
2. Copia sobre ese proyecto: `pubspec.yaml`, `lib/main.dart` y la carpeta `assets` de este paquete.
3. En console.firebase.google.com crea un proyecto, activa **Authentication (correo/contraseña)** y **Firestore**.
4. Ejecuta `dart pub global activate flutterfire_cli` y luego `flutterfire configure`.
5. Pega `firestore.rules` en Firestore > Reglas > Publicar.
6. Crea tu usuario en Authentication y, en Firestore, un documento `users/<UID>` con el campo `role: "admin"`. Los vendedores no necesitan documento.
7. `flutter pub get` y `flutter run`.

## Escudo de seguridad (en AndroidManifest.xml, dentro de <application>)
android:allowBackup="false"
android:usesCleartextTraffic="false"

## Compilar versión protegida
flutter build apk --release --obfuscate --split-debug-info=build/symbols
Firma el APK con tu propia clave (keystore) y guárdala fuera del proyecto.
Activa Firebase App Check (Play Integrity) en la consola para rechazar apps falsas.

Los precios de referencia (USD/t) están en `refProducts` de lib/main.dart: actualízalos con cada cotización.
El acuse se genera en PDF desde la pestaña Acuse (mínimo 20 t) y se guarda en Firestore (colección acuses).

## Ícono de la app
Después de `flutter pub get` ejecuta: `dart run flutter_launcher_icons` (usa assets/icon.png con tu logo).

## Indicadores
Nube con check = sincronizado. Nube tachada = pedido guardado offline, pendiente de envío.
