# E&W – App web instalable (MxCu Ventures S.A.)

Carpeta `public/` = la app. `firestore.rules` = reglas de seguridad. `firebase.json` = publicación segura (HTTPS y cabeceras).

## 1. Crear el proyecto Firebase (gratis, plan Spark)
1. console.firebase.google.com → Agregar proyecto (nombre: ew-mxcu).
2. **Authentication** → Comenzar → Método de acceso → activar **Correo electrónico/contraseña**.
3. **Firestore Database** → Crear base de datos → modo **producción** → pestaña **Reglas** → pega el contenido de `firestore.rules` → Publicar.
4. Configuración del proyecto (⚙) → Tus apps → icono web `</>` → registra la app → copia el bloque `firebaseConfig` y pégalo en `public/config.js`.

## 2. Publicar (necesita computadora una sola vez)
```
npm install -g firebase-tools
firebase login
firebase use --add      # elige tu proyecto
firebase deploy
```
Te dará un enlace `https://TU-PROYECTO.web.app`: ese es el que compartes con clientes y empresas.
(Alternativa sin Firebase Hosting: sube la carpeta `public/` a Netlify o Cloudflare Pages y añade ese dominio en Authentication → Configuración → Dominios autorizados.)

## 3. Primer administrador
1. Abre el enlace y regístrate con tu correo.
2. En Firestore → `users` → tu documento → cambia `role` de `client` a `admin`. Cierra sesión y vuelve a entrar.
3. En Catálogo toca "Cargar catálogo de referencia" y guarda el correo del proveedor para los avisos.

## 4. Instalar en el celular
Abre el enlace en Chrome → menú ⋮ → **Instalar app**. Se instala con el ícono morado y amarillo con tu logo.

## Seguridad incluida
Cada cliente solo lee sus pedidos y acuses; el administrador lee todo. Nadie puede hacerse administrador desde la app. Al confirmar una compra se borran del cliente su pedido y su acuse. Cuentas con contraseña, bloqueo tras 5 intentos fallidos, HTTPS y cabeceras de seguridad. Recomendado: activar **App Check** y restringir la API key por dominio en Google Cloud.

## Limitaciones
- El correo se abre como borrador en el teléfono (un toque en Enviar). El envío automático requiere la extensión "Trigger Email" de Firebase.
- Los avisos aparecen con la app abierta; notificaciones push con la app cerrada requieren configurar Firebase Cloud Messaging.
